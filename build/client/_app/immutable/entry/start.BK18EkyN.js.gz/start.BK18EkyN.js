import{a as t}from"../chunks/entry.BYN3NfBT.js";export{t as start};
